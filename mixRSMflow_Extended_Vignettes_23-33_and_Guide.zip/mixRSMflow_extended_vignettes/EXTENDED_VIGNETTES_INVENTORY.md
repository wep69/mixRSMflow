# Extended Vignettes Inventory

| File | Words | Lines | Code-fence check |
|:--|--:|--:|:--|
| `23-foundations-to-advanced-tutorial-mixRSMflow.md` | 12910 | 3849 | PASS |
| `24-constrained-mixture-geometry-and-pseudocomponents.md` | 6015 | 1316 | PASS |
| `25-optimal-mixture-design-and-design-quality.md` | 5747 | 1393 | PASS |
| `26-alternative-blending-models.md` | 5255 | 1201 | PASS |
| `27-mixture-process-and-structured-experiments.md` | 4423 | 1018 | PASS |
| `28-multiple-responses-desirability-and-pareto.md` | 4212 | 992 | PASS |
| `29-optimum-location-uncertainty-and-near-optimal-regions.md` | 4148 | 966 | PASS |
| `30-sequential-mixture-experimentation.md` | 3929 | 917 | PASS |
| `31-generalized-hierarchical-and-bayesian-mixture-models.md` | 4417 | 992 | PASS |
| `32-publication-graphics-for-mixture-experiments.md` | 4125 | 1045 | PASS |
| `33-validation-benchmarking-and-reproducibility.md` | 4808 | 1208 | PASS |
| `VIGNETTE_STRUCTURE_AND_INTEGRATION_GUIDE.md` | 2689 | 750 | PASS |
