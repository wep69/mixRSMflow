## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"))
d <- mix_demo_data("mixture",n_rep=2,seed=25)
fit2 <- mix_fit("response",d,sp,"scheffe_quadratic")
fit3 <- mix_fit("response",d,sp,"scheffe_special_cubic")
mix_compare(fit2,fit3)

