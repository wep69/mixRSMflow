## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)
library(mixRSMflow)

## ----index-region-------------------------------------------------------------
sp <- mix_spec(c("A", "B", "C"))
spc <- mix_spec(c("A", "B", "C"), lower = c(.1, .1, .1), upper = c(.7, .8, .8))
mix_vertices(spc); nrow(mix_vertices(spc))
mix_region(sp, type = "sphere", radius = .2)
mix_region(sp, type = "cuboid", lower_y = c(-.1, -.1), upper_y = c(.1, .1))$region
X <- data.frame(A = .2, B = .3, C = .5)
mix_pseudocomponents(X, spc, "L")
mix_pseudocomponents(X, spc, "U")
mix_pseudocomponents(mix_pseudocomponents(X, spc, "L"), spc, "L", inverse = TRUE)
Y <- mix_transform(X, sp)
mix_transform(data.frame(A = .5, B = .3, C = .2), sp)
mix_inverse_transform(Y, sp)
mix_inverse_transform(matrix(c(0, .1), 1), sp)
mix_reparameterize(mix_fit("response", mix_demo_data("mixture", n_rep = 2, seed = 1), sp, "scheffe_quadratic"), slack_component = "C")
mix_reparameterize(mix_fit("response", mix_demo_data("mixture", n_rep = 2, seed = 1), sp, "scheffe_linear"), slack_component = "B")

## ----index-designs------------------------------------------------------------
mix_multiple_lattice(sp, major = c("A", "B"), minor = "C", major_totals = c(.5, .5), major_degree = 1, minor_degree = 2)$data
mix_multiple_lattice(sp, major = c("A", "B"), minor = "C", major_totals = c(.6, .4), major_degree = 2, minor_degree = 1)$data
mix_categorized_design(sp, categories = list(base = c("A", "B"), additive = "C"), between_degree = 2, within_degree = 1)
mix_categorized_design(sp, categories = list(base = c("A", "B"), additive = "C"), between_degree = 1, within_degree = 2)
mix_latin_process_design(sp, list(temp = c(20, 30)), list(time = c(1, 2)))
mix_latin_process_design(sp, list(temp = c(20, 30, 40)), list(time = c(1, 2, 3)))
d <- mix_design(sp, "simplex_lattice", degree = 3)
mix_block_design(d, n_blocks = 3, iterations = 200, seed = 3)
mix_block_design(d, n_blocks = 2, iterations = 200, seed = 4)
full <- mix_design(sp, "mixture_process", process = list(temp = c(-1, 1), speed = c(-1, 1)))
mix_fractionate_process(full, process = c("temp", "speed"), fraction = 0.5, model = "scheffe_linear", process_order = 1)
mix_fractionate_process(full, process = c("temp", "speed"), fraction = 0.75, model = "scheffe_linear", process_order = 1)
mix_optimal_design(sp, model = "scheffe_quadratic", runs = 8, criterion = "D", algorithm = "exchange", resolution = 6, max_iter = 20, seed = 5)
mix_optimal_design(sp, model = "scheffe_quadratic", runs = 8, criterion = "I", algorithm = "exchange", resolution = 6, max_iter = 20, seed = 6)
mix_augment(d, n_new = 1, model = "scheffe_quadratic", objective = "D", resolution = 6)
mix_augment(d, n_new = 1, model = "scheffe_quadratic", objective = "I", resolution = 6)
mix_design_eval(d, model = "scheffe_quadratic", resolution = 6)$measures

## ----index-models-------------------------------------------------------------
mix_basis(d$data, sp, "scheffe_special_cubic")
t1 <- mix_gbm_term(c("A", "B"), g = c(2, 2), h = .5, s = 2)
mix_basis(data.frame(A = .2, B = .3, C = .5), sp, "gbm", gbm_terms = list(t1))
mix_moments(sp, powers = c(1, 0, 0), method = "exact")
mix_moments(sp, powers = c(1, 1, 0), method = "monte_carlo", n = 20000, seed = 2)
fitq <- mix_fit("response", mix_demo_data("mixture", n_rep = 2, seed = 1), sp, "scheffe_quadratic")
mix_reduce(fitq, criterion = "aic")
mix_reduce(fitq, criterion = "bic")

## ----index-inference----------------------------------------------------------
dd <- mix_demo_data("mixture", n_rep = 2, seed = 9)
fit <- mix_fit("response", dd, sp, "scheffe_quadratic")
mix_anova(fit)
mix_anova(mix_fit("response", mix_demo_data("mixture", n_rep = 3, seed = 10), sp, "scheffe_quadratic"))
mix_diagnose(fit)
mix_collinearity(fit)
mix_collinearity(dd, spec = sp, model = "scheffe_quadratic")
mix_compare(fit, mix_fit("response", dd, sp, "scheffe_special_cubic"), criterion = "AIC")
mix_compare(fit, mix_fit("response", dd, sp, "scheffe_linear"), criterion = "BIC")
mix_screen(fit, direction = "cox")
mix_screen(fit, direction = "piepel")
mix_imse(mix_design(sp, "simplex_lattice", degree = 3), fitted_model = "scheffe_quadratic", true_model = "scheffe_special_cubic", beta_omitted = c(`A:B:C` = 2), sigma2 = .25, resolution = 8)
mix_imse(mix_design(sp, "simplex_lattice", degree = 3), fitted_model = "scheffe_quadratic", true_model = "scheffe_special_cubic", beta_omitted = c(`A:B:C` = 2), sigma2 = .25, resolution = 6)
mix_effects(fit, type = "cox", component = "A")
mix_effects(fit, type = "component_trace", component = "A")
mix_rotatability(dd, spec = sp, model = "scheffe_quadratic", resolution = 8)
mix_rotatability(mix_design(sp, "simplex_lattice", degree = 4), model = "scheffe_quadratic", resolution = 8)

## ----index-predict-optimize---------------------------------------------------
mix_predict(fit, interval = "confidence")
mix_predict(fit, newdata = d$data[1:3, ], interval = "prediction")
sf <- mix_segmented_fit("response", dd, sp, split_component = "A", cut = .3,
                        model_left = "scheffe_linear", model_right = "scheffe_linear")
mix_predict_segmented(sf)
mix_predict_segmented(sf, interval = "confidence")
mix_segmented_fit("response", dd, sp, split_component = "B", cut = .4,
                  model_left = "scheffe_linear", model_right = "scheffe_linear")
op <- mix_optimize(fit, goal = "maximize", method = "grid", grid_resolution = 15)
mix_optimum_ci(op, method = "parametric", B = 60, seed = 3)
mix_optimum_ci(op, method = "residual_bootstrap", B = 60, seed = 3)
dm <- mix_demo_data("multiresponse", n_rep = 2, seed = 13)
mf <- mix_multi_fit(c("quality", "stability"), dm, sp, model = "scheffe_quadratic")
mix_biplot(mf, plot = FALSE)
mix_biplot(mf, plot = FALSE, scale = FALSE)
mix_multiopt(mf, goals = c(quality = "maximize", stability = "maximize"), settings = list(quality = list(low = min(dm$quality), high = max(dm$quality)), stability = list(low = min(dm$stability), high = max(dm$stability))), resolution = 9)
mix_multiopt(mf, goals = c(quality = "maximize", stability = "minimize"), settings = list(quality = list(low = min(dm$quality), high = max(dm$quality)), stability = list(low = min(dm$stability), high = max(dm$stability))), resolution = 7)

## ----index-backends-----------------------------------------------------------
if (requireNamespace("nlme", quietly = TRUE)) {
  mix_fit_gls("response", dd, sp, model = "scheffe_quadratic", correlation = nlme::corAR1(form = ~1))
  mix_fit_gls("response", dd, sp, model = "scheffe_linear", method = "ML")
}
if (requireNamespace("lme4", quietly = TRUE)) {
  dd2 <- dd[rep(seq_len(nrow(dd)), each = 2), ]
  dd2$block <- factor(rep(1:2, nrow(dd)))
  mix_fit_mixed("response", dd2, sp, random = "(1|block)", model = "scheffe_quadratic")
  mix_fit_mixed("response", dd2, sp, random = "(1|block)", model = "scheffe_linear")
}
if (FALSE) {
  mix_fit_bayes("response", dd, sp, model = "scheffe_quadratic")
  mix_fit_bayes("response", dd, sp, model = "scheffe_linear")
}
if (requireNamespace("DiceKriging", quietly = TRUE)) {
  mix_bo(dd, "response", sp, goal = "maximize", iterations = 1, candidate_n = 300, seed = 2)
  mix_bo(dd, "response", sp, goal = "minimize", iterations = 1, candidate_n = 300, seed = 2)
}

## ----index-reporting----------------------------------------------------------
mix_report(fit, format = "markdown", include_session = FALSE)$source
mix_report(fit, format = "markdown", include_session = FALSE, title = "QA report")$source
mix_audit_trail(fit)
mix_audit_trail(mix_optimal_design(sp, model = "scheffe_quadratic", runs = 8, criterion = "D", algorithm = "exchange", resolution = 6, max_iter = 20, seed = 5))
mix_capabilities(module = "design")
mix_capabilities(tier = 1)
args(run_mixrsm_app)
formals(run_mixrsm_app)

## ----index-completion---------------------------------------------------------
# Third demonstrations so every public function appears at least three times.
mix_report(fit, format = "markdown", include_session = FALSE, title = "Final QA")$source
mix_imse(mix_design(sp, "simplex_lattice", degree = 3), fitted_model = "scheffe_quadratic", true_model = "scheffe_special_cubic", beta_omitted = c(`A:B:C` = 2), sigma2 = .25, resolution = 5)
mix_screen(fit, direction = "cox", level = .9)
mix_bo(dd, "response", sp, goal = "maximize", iterations = 1, candidate_n = 200, seed = 7)
mix_fit_mixed("response", dd2, sp, random = "(1|block)", model = "scheffe_quadratic")
mix_rotatability(mix_design(sp, "simplex_lattice", degree = 3), model = "scheffe_quadratic", resolution = 6)
mix_segmented_fit("response", dd, sp, split_component = "C", cut = .3, model_left = "scheffe_linear", model_right = "scheffe_linear")
mix_predict(fit)
mix_fractionate_process(full, process = c("temp", "speed"), fraction = 0.9, model = "scheffe_linear", process_order = 1)
mix_multiopt(mf, goals = c(quality = "maximize", stability = "maximize"), settings = list(quality = list(low = min(dm$quality), high = max(dm$quality)), stability = list(low = min(dm$stability), high = max(dm$stability))), resolution = 8)
mix_fit_gls("response", dd, sp, model = "scheffe_quadratic", method = "REML")
mix_predict_segmented(sf, interval = "prediction")
mix_multiple_lattice(sp, major = c("A", "B"), minor = "C", major_totals = c(.5, .5), major_degree = 2, minor_degree = 2)$data
mix_moments(sp, powers = c(0, 1, 0), method = "exact")
mix_region(sp, type = "ellipsoid", shape = diag(2))$region
mix_reparameterize(fit, slack_component = "A")
mix_categorized_design(sp, categories = list(base = c("A", "B"), additive = "C"), between_degree = 2, within_degree = 2)
mix_multi_fit(c("quality", "stability"), dm, sp, model = "scheffe_linear")
mix_reduce(fit, criterion = "press")
mix_capabilities(module = "optimization")
if (FALSE) {
  mix_fit_bayes("response", dd, sp, model = "scheffe_quadratic")
  run_mixrsm_app(launch.browser = FALSE)
  run_mixrsm_app(demo = TRUE)
}

