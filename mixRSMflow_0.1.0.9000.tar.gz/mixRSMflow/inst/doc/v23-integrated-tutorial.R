## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", warning = FALSE,
                      message = FALSE, fig.width = 7, fig.height = 5, out.width = "90%")
library(mixRSMflow)
library(ggplot2)

# Robust citation string: reads citation(), falling back to the package DESCRIPTION.
cite_mix <- function() {
  cit <- tryCatch(suppressWarnings(utils::citation("mixRSMflow")), error = function(e) NULL)
  if (!is.null(cit)) {
    txt <- paste(format(cit[[1]]), collapse = " ")
    if (!grepl("Contributors", txt, fixed = TRUE) && !grepl("REPLACE_WITH", txt, fixed = TRUE)) return(txt)
  }
  p <- system.file("DESCRIPTION", package = "mixRSMflow")
  if (file.exists(file.path("..", "DESCRIPTION"))) p <- file.path("..", "DESCRIPTION")
  d <- read.dcf(p, all = TRUE)
  au <- eval(parse(text = d[["Authors@R"]]))
  auth <- paste(vapply(au, function(x) {
    paste(paste(format(x, include = "given"), collapse = " "), format(x, include = "family"))
  }, character(1)), collapse = ", ")
  sprintf("%s (%s). %s. R package version %s.", auth, format(Sys.Date(), "%Y"),
          gsub("\\s+", " ", d[["Title"]]), d[["Version"]])
}

## ----flow1-spec---------------------------------------------------------------
sp <- mix_spec(c("A", "B", "C"), units = "mass fraction")
sp

## ----flow1-designs------------------------------------------------------------
sc <- mix_design(sp, "simplex_centroid")          # 7 points
sl <- mix_design(sp, "simplex_lattice", degree = 3) # 10 points
cat("simplex_centroid runs:", nrow(sc$data), "\n")
cat("simplex_lattice {3,3} runs:", nrow(sl$data), "\n")
sl$data

## ----flow1-data---------------------------------------------------------------
set.seed(2026)                                   # fixed seed
base <- sl$data
d <- base[rep(seq_len(nrow(base)), each = 2), , drop = FALSE]  # 2 replicates per blend
d$.run <- seq_len(nrow(d))
mu <- with(d, 40*A + 30*B + 28*C + 30*A*B + 32*A*C + 10*B*C)
d$strength <- mu + rnorm(nrow(d), 0, 1.1)        # noise sd = 1.1 MPa
cat("observations:", nrow(d), "\n")
head(d)

## ----flow1-fit----------------------------------------------------------------
fit <- mix_fit("strength", d, sp, model = "scheffe_quadratic")
fit

## ----flow1-anova--------------------------------------------------------------
an <- mix_anova(fit)
an
lof_p <- an$p_value[an$source == "Lack of fit"]
Freg  <- an$MS[an$source == "Regression"] / an$MS[an$source == "Residual"]
preg  <- pf(Freg, an$df[an$source == "Regression"], an$df[an$source == "Residual"], lower.tail = FALSE)
R2    <- 1 - an$SS[an$source == "Residual"] / an$SS[an$source == "Total"]

## ----flow1-diagnose-----------------------------------------------------------
dg <- mix_diagnose(fit)
dg

## ----fig-flow1-resid, fig.cap="Residual diagnostics for the Scheffe quadratic fit"----
mix_plot(fit, "residuals")

## ----fig-flow1-qq, fig.cap="Normal Q-Q plot of the residuals"-----------------
mix_plot(fit, "qq")

## ----flow1-cox----------------------------------------------------------------
eA <- mix_effects(fit, type = "cox", component = "A", n = 51)
eA

## ----fig-flow1-cox, fig.cap="Cox effect of cement (A) with a 95% confidence band"----
mix_plot(eA)

## ----fig-flow1-contour, fig.cap="Continuous ternary contour of predicted 28-day strength (MPa)"----
mix_plot(fit, "ternary_contour", resolution = 40)

## ----fig-flow1-filled, fig.cap="Filled ternary contour of the same surface"----
mix_plot(fit, "ternary_filled", resolution = 40)

## ----fig-flow1-surface3d, fig.cap="Cornell-style 3D wireframe of the strength surface (base graphics)"----
mix_plot(fit, "surface3d", engine = "base", views = 2)

## ----flow1-report-------------------------------------------------------------
mix_report(fit, title = "Flow 1: Scheffe mixture analysis of compressive strength")

## ----flow2-trace--------------------------------------------------------------
eB <- mix_effects(fit, type = "component_trace", component = "B", n = 51)
eB

## ----fig-flow2-trace, fig.cap="Component trace of fly ash (B) with a 95% confidence band"----
mix_plot(eB)

## ----flow2-optimize-----------------------------------------------------------
op <- mix_optimize(fit, "maximize", method = "grid", grid_resolution = 30, seed = 5)
op

## ----flow2-optci--------------------------------------------------------------
ci <- mix_optimum_ci(op, method = "parametric", B = 999, grid_resolution = 8, seed = 7)
ci

## ----fig-flow2-optci, fig.cap="Parametric cloud of optimum locations (999 simulated surfaces)"----
mix_plot(ci, "optimum_ci")

## ----flow2-compare------------------------------------------------------------
f_sq  <- mix_fit("strength", d, sp, model = "scheffe_quadratic")
f_bh2 <- mix_fit("strength", d, sp, model = "becker_h2")
f_sl  <- mix_fit("strength", d, sp, model = "slack_quadratic")
g1 <- mix_gbm_term(c("A", "B"), g = c(1, 1), h = 0.5, s = 1.5, label = "AB_gbm")
g2 <- mix_gbm_term(c("A", "C"), g = c(1, 1), h = 0.5, s = 1.5, label = "AC_gbm")
g3 <- mix_gbm_term(c("B", "C"), g = c(1, 1), h = 0.5, s = 1.5, label = "BC_gbm")
f_gbm <- mix_fit("strength", d, sp, model = "gbm", gbm_terms = list(g1, g2, g3))
cmp <- mix_compare(f_sq, f_bh2, f_sl, f_gbm, criterion = "AIC")
knitr::kable(cmp[, c("model", "p", "AIC", "BIC", "RMSE")], digits = 3,
             caption = "Honest fit-quality comparison across model families.")

## ----flow3-design-------------------------------------------------------------
dmp <- mix_design(sp, "mixture_process",
                  process = list(temperature = c(20, 40, 60), time = c(30, 60)),
                  degree = 2)
cat("mixture-process runs:", nrow(dmp$data), "\n")
head(dmp$data)

## ----flow3-data---------------------------------------------------------------
set.seed(99)                                    # fixed seed
mpd <- dmp$data
mpmu <- with(mpd, 40*A + 30*B + 28*C + 30*A*B + 32*A*C + 10*B*C +
                 0.15*temperature + 0.02*time + 0.08*A*temperature)
mpd$strength <- mpmu + rnorm(nrow(mpd), 0, 0.6)  # smaller noise so the process effects are clear

## ----flow3-fit----------------------------------------------------------------
fitmp <- mix_fit("strength", mpd, sp, model = "scheffe_quadratic",
                 process = c("temperature", "time"),
                 process_order = 1, mixture_process = TRUE)
summary(fitmp)$coefficients

## ----flow3-slices-------------------------------------------------------------
trA <- seq(0, 1, length.out = 41)
slices <- lapply(c(20, 40, 60), function(T0) {
  nd <- data.frame(A = trA)
  nd$B <- (1 - nd$A) / 2
  nd$C <- (1 - nd$A) / 2
  nd$temperature <- T0
  nd$time <- 45
  mix_predict(fitmp, nd, interval = "confidence")
})
slices <- do.call(rbind, slices)
slices$temperature <- factor(slices$temperature)
head(slices)

## ----fig-flow3-slices, fig.cap="Predicted strength versus cement (A) at three curing temperatures"----
ggplot(slices, aes(A, .prediction, color = temperature, fill = temperature)) +
  geom_line() +
  geom_ribbon(aes(ymin = .lower, ymax = .upper), alpha = 0.15, color = NA) +
  labs(x = "A (cement, mass fraction)", y = "Predicted strength (MPa)",
       color = "Temperature (C)", fill = "Temperature (C)") +
  theme_minimal()

## ----flow4-data---------------------------------------------------------------
dmr <- mix_demo_data("multiresponse", n_rep = 2, seed = 71)
head(dmr)
mf <- mix_multi_fit(c("quality", "stability", "cost"), dmr, sp,
                    model = "scheffe_quadratic")
mf

## ----flow4-multiopt-----------------------------------------------------------
goals <- c(quality = "maximize", stability = "maximize", cost = "minimize")
settings <- list(
  quality   = list(low = min(dmr$quality),   high = max(dmr$quality)),
  stability = list(low = min(dmr$stability), high = max(dmr$stability)),
  cost      = list(low = min(dmr$cost),      high = max(dmr$cost)))
mo <- mix_multiopt(mf, goals, settings, resolution = 20, random_candidates = 1000, seed = 3)
mo

## ----fig-flow4-desirability, fig.cap="Ternary desirability map of the three-response compromise"----
mix_plot(mo, "desirability")

## ----fig-flow4-pareto, fig.cap="Trade-off between the first two responses with the Pareto set highlighted"----
mix_plot(mo, "pareto")

## ----fig-flow4-biplot, fig.cap="PCA biplot summarizing the predicted response patterns"----
mix_biplot(mf, resolution = 12)$plot

## ----flow4-report-------------------------------------------------------------
mix_report(list(multi_fit = mf), title = "Flow 4: multiresponse mixture analysis")

## ----workflow-diagram, fig.cap="Complete mixRSMflow workflow"-----------------
if (requireNamespace("DiagrammeR", quietly = TRUE)) {
  DiagrammeR::mermaid("flowchart LR
  A[mix_spec] --> B[mix_design]
  B --> C[measure / simulate data]
  C --> D[mix_fit]
  D --> E[mix_anova + mix_diagnose]
  D --> F[mix_predict + mix_effects]
  E --> G[mix_optimize / mix_multiopt]
  F --> G
  G --> H[mix_optimum_ci]
  G --> I[mix_report]")
} else {
  cat("spec -> design -> data -> fit -> diagnose -> predict -> optimize -> report\n")
}

## ----ex2----------------------------------------------------------------------
set.seed(2026)
d2 <- base[rep(seq_len(nrow(base)), each = 2), , drop = FALSE]
d2$strength <- with(d2, 45*A + 20*B + 18*C + 15*A*B) + rnorm(nrow(d2), 0, 1.1)
fit2 <- mix_fit("strength", d2, sp, model = "scheffe_quadratic")
an2 <- mix_anova(fit2)
c(R2 = 1 - an2$SS[an2$source == "Residual"] / an2$SS[an2$source == "Total"],
  lof_p = an2$p_value[an2$source == "Lack of fit"])

## ----ex5----------------------------------------------------------------------
spc <- mix_spec(c("A", "B", "C"), lower = c(0.1, 0, 0), units = "mass fraction")
dc  <- mix_design(spc, "mixture_process", base_type = "simplex_lattice", degree = 3,
                  process = list(temperature = c(20, 40, 60)))
set.seed(1)
dc$data$y <- with(dc$data, 40*A + 30*B + 28*C + 30*A*B + 0.15*temperature +
                  rnorm(nrow(dc$data), 0, 0.5))
fc <- mix_fit("y", dc, spc, model = "scheffe_quadratic",
              process = "temperature", process_order = 1, mixture_process = TRUE)
# three temperature levels allow order 1 (and order 2 for this single factor)
nd <- data.frame(A = seq(0.1, 1, length.out = 21))
nd$B <- (1 - nd$A) / 2; nd$C <- (1 - nd$A) / 2; nd$temperature <- 40
mix_predict(fc, nd, interval = "confidence")[c("A", ".prediction", ".lower", ".upper")]

