## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"))
d <- data.frame(A=c(.2,.3,.4), B=c(.3,.4,.2), C=c(.5,.3,.4))
mix_basis(d,sp,"becker_h2")
term <- mix_gbm_term(c("A","B"), g=c(2,2), h=.5, s=1, label="AB_H2")
mix_basis(d,sp,"gbm",gbm_terms=list(term))

