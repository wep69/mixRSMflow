## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----include-extended, results='asis', echo=FALSE-----------------------------
src <- system.file("monographs",
                   "33-validation-benchmarking-and-reproducibility.md",
                   package = "mixRSMflow")
if (nzchar(src)) {
  cat(readLines(src, warn = FALSE, encoding = "UTF-8"), sep = "\n")
} else {
  cat("**Extended tutorial not found in the installed package.**\n")
}

