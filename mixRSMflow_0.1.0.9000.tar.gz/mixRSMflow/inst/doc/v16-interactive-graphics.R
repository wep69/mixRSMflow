## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## ----eval=FALSE---------------------------------------------------------------
# library(mixRSMflow)
# sp <- mix_spec(c("A","B","C"))
# d <- mix_demo_data("mixture",n_rep=1,seed=121)
# fit <- mix_fit("response",d,sp,"scheffe_quadratic")
# mix_plot(fit,"surface3d",engine="plotly",resolution=25)

