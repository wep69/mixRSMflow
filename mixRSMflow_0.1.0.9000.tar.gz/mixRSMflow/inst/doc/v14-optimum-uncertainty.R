## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## ----eval=FALSE---------------------------------------------------------------
# library(mixRSMflow)
# sp <- mix_spec(c("A","B","C"))
# d <- mix_demo_data("mixture",n_rep=3,seed=101)
# fit <- mix_fit("response",d,sp,"scheffe_quadratic")
# op <- mix_optimize(fit,"maximize",grid_resolution=20)
# ci <- mix_optimum_ci(op,method="parametric",B=500,seed=102)
# ci
# mix_plot(ci,"optimum_ci")

