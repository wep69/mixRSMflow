## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"), lower=c(.10,.05,.05), upper=c(.70,.80,.80),
               A=matrix(c(1,1,0),1), b=.75, dir="<=")
V <- mix_vertices(sp)
V
ev <- mix_design(sp,"extreme_vertices")

