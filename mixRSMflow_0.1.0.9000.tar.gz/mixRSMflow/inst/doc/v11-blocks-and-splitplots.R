## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"))
d <- mix_design(sp,"simplex_lattice",degree=3)
bd <- mix_block_design(d,2,iterations=1000,seed=3)
bd$block_diagnostics
lat <- mix_latin_process_design(sp,list(temp=c(20,30,40)),list(time=c(1,2,3)))
head(lat$data)

