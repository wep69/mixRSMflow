## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----include-extended, results='asis', echo=FALSE-----------------------------
src <- system.file("monographs", "
27-mixture-process-and-structured-experiments.md
", package = "mixRSMflow")
if (nzchar(src)) {
  cat(readLines(src, warn = FALSE, encoding = "UTF-8"), sep = "\n")
} else {
  cat("**Extended tutorial not found.**\n")
}

