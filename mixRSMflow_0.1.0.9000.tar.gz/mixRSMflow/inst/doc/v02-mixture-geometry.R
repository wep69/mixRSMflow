## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"), total = 1)
x <- data.frame(A=.20, B=.35, C=.45)
y <- mix_transform(x, sp)
y
mix_inverse_transform(y, sp)

