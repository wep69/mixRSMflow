## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"))
d <- mix_demo_data("multiresponse",n_rep=2,seed=71)
mf <- mix_multi_fit(c("quality","stability"),d,sp,model="scheffe_quadratic")
bp <- mix_biplot(mf,resolution=12)
bp$plot

