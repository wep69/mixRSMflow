## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A", "B", "C"))
des <- mix_design(sp, "simplex_centroid")
dat <- mix_demo_data("mixture", n_rep = 2, seed = 20260813)
fit <- mix_fit("response", dat, sp, model = "scheffe_quadratic")
summary(fit)
mix_diagnose(fit)
opt <- mix_optimize(fit, goal = "maximize", grid_resolution = 18, method = "grid")
opt

