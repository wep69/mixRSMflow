## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"))
d <- mix_demo_data("mixture",n_rep=2,seed=41)
fit <- mix_fit("response",d,sp,"scheffe_quadratic")
e <- mix_effects(fit,type="cox",component="A",n=25)
head(e$path)
mix_plot(e)

