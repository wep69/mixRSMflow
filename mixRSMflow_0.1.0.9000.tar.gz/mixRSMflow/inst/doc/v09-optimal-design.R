## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## ----eval=FALSE---------------------------------------------------------------
# library(mixRSMflow)
# sp <- mix_spec(c("A","B","C"),lower=c(.05,.05,.05))
# od <- mix_optimal_design(sp,"scheffe_quadratic",runs=10,criterion="I",
#                          algorithm="hybrid",seed=91)
# ev <- mix_design_eval(od,model="scheffe_quadratic")
# mix_plot(ev,"fds")

