## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"))
sl <- mix_design(sp, "simplex_lattice", degree = 3)
sc <- mix_design(sp, "simplex_centroid")
ax <- mix_design(sp, "axial")
head(sl$data)
mix_plot(sc, type = "design")

