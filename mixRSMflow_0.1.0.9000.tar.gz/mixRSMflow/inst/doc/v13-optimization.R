## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"))
d <- mix_demo_data("mixture",n_rep=2,seed=81)
fit <- mix_fit("response",d,sp,"scheffe_quadratic")
mix_optimize(fit,"maximize",method="grid",grid_resolution=20)

