## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----include-extended, results='asis', echo=FALSE-----------------------------
src <- system.file("monographs", "
23-foundations-to-advanced-tutorial-mixRSMflow.md
", package = "mixRSMflow")
if (nzchar(src)) {
  cat(readLines(src, warn = FALSE, encoding = "UTF-8"), sep = "\n")
} else {
  cat("**Extended tutorial not found.**\n")
}

