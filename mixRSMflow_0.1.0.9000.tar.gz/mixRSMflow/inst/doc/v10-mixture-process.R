## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"))
d <- mix_design(sp,"mixture_process",process=list(temp=c(20,40),time=c(1,3)),degree=2)
set.seed(2); d$data$y <- with(d$data,4*A+6*B+5*C+.03*temp+A*temp/20+rnorm(nrow(d$data),0,.05))
# Two-level process factors only support linear process effects: a quadratic
# process model (process_order = 2) is rank deficient on this crossed design.
fit <- mix_fit("y",d,model="scheffe_quadratic",process=c("temp","time"),
               process_order=1,mixture_process=TRUE)
summary(fit)

