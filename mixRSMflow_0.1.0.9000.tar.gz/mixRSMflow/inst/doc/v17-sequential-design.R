## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## ----eval=FALSE---------------------------------------------------------------
# library(mixRSMflow)
# sp <- mix_spec(c("A","B","C"))
# d0 <- mix_design(sp,"simplex_centroid")
# d1 <- mix_augment(d0,n_new=3,model="scheffe_quadratic",objective="I",resolution=10)
# mix_design_eval(d1,model="scheffe_quadratic")

