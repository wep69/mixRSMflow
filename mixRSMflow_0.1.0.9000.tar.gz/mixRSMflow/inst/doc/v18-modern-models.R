## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## -----------------------------------------------------------------------------
library(mixRSMflow)
sp <- mix_spec(c("A","B","C"))
t <- mix_gbm_term(c("A","B"),g=c(2,2),h=.5,s=2,label="AB")
d <- mix_demo_data("mixture",n_rep=1,seed=131)
fit <- mix_fit("response",d,sp,model="gbm",gbm_terms=list(t))
fit

