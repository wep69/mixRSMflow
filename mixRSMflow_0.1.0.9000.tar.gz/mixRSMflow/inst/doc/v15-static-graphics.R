## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 7, fig.height = 5)

## ----eval=FALSE---------------------------------------------------------------
# library(mixRSMflow)
# sp <- mix_spec(c("A","B","C"))
# d <- mix_demo_data("mixture",n_rep=2,seed=115)
# fit <- mix_fit("response",d,sp,"scheffe_quadratic")
# mix_plot(fit,"surface3d",engine="base",views=2,file="surface.pdf")
# mix_plot(fit,"ternary_contour",file="contour.pdf")

