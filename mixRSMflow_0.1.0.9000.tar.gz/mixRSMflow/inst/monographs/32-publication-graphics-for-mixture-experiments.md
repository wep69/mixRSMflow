# mixRSMflow: Publication Graphics and Interactive Visualization for Mixture Experiments

**Extended instructional vignette**  
**Package:** `mixRSMflow`  
**Version targeted:** `0.1.0.9000`  
**Extended vignette:** 32  
**Format:** Markdown source only  
**Primary ownership:** scientific visualization, ternary design and response maps, prediction-variance maps, diagnostics, FDS/VDG, optimum and uncertainty graphics, vector dual-view 3D surfaces, high-resolution raster output, optional Plotly interaction, and figure-reporting standards  
**Companion material:** `15-static-graphics.Rmd`, `16-interactive-graphics.Rmd`

> This document is intentionally supplied as `.md`. The statistical quantities displayed by a figure should be generated from validated numeric objects. A beautiful graphic is not a substitute for an adequate design or model.

> **Scope boundary.** This extended vignette owns the topic named in its title. Closely related methods that belong to another extended vignette are referenced rather than re-taught. This separation is deliberate so that the extended documentation remains deep without becoming repetitive.

---

## 1. Why graphics deserve their own scientific workflow

Mixture experiments are geometric. A coefficient table alone rarely communicates where the experiment was conducted, which parts of the simplex are feasible, where the response surface rises or falls, or how uncertain predictions are near the boundaries.

At the same time, mixture graphics are easy to misuse. A smooth colored triangle can visually imply information in regions that were never observed, and a 3D surface can exaggerate small curvature through perspective.

The central principle is:

**Use graphics to expose design support, model shape, uncertainty, and decision geometry—not to hide them.**

`mix_plot()` provides a common plotting interface across major `mixRSMflow` objects.

---

## 2. Learning objectives

After this vignette, the reader should be able to:

1. choose a plot type according to the scientific object being communicated;
2. produce ternary design plots for three-component systems;
3. display response contours and filled response surfaces;
4. distinguish a response heat map from a prediction-variance map;
5. create component-effect and diagnostic figures;
6. create FDS and VDG design-quality graphics;
7. display exact optima, near-optimal regions, and joint optimum uncertainty;
8. produce multiresponse desirability and Pareto displays;
9. create a recalculated dual-view 3D mixture surface with vector PDF/SVG output;
10. create 600-dpi PNG/TIFF output when raster files are required;
11. use optional Plotly 3D interaction for exploration and teaching;
12. preserve numeric prediction data independently of browser widgets;
13. select dimensions and labels suitable for journals, theses, slides, and teaching;
14. show observed design points whenever they improve interpretation;
15. avoid misleading interpolation or visual extrapolation;
16. build a complete graphical suite for one mixture analysis.

---

## 3. Function map

| Graphic family | `mix_plot()` use |
|:--|:--|
| Design support | `type="design"` |
| Ternary contours | `type="ternary_contour"` |
| Filled ternary surface | `type="ternary_filled"` |
| Heat-map style surface | `type="heatmap"` |
| Vector/perspective surface | `type="surface3d"` |
| Prediction uncertainty | `type="prediction_variance"` |
| Residuals | `type="residuals"` |
| Q-Q | `type="qq"` |
| Leverage/influence | `type="leverage"` |
| Component effect | `mix_plot(mix_effects(...))` |
| FDS | `type="fds"` |
| VDG | `type="vdg"` |
| Optimum | `type="optimum"` |
| Optimum uncertainty | `type="optimum_ci"` |
| Multiresponse compromise | `type="desirability"` |
| Pareto front | `type="pareto"` |
| Interactive | `engine="plotly"` where supported |

---

# Part I. Build a common teaching object

## 4. Fit a response surface

```r
library(mixRSMflow)

sp <- mix_spec(c("A", "B", "C"))
d <- mix_demo_data("mixture", n_rep = 3, seed = 32001)

fit <- mix_fit(
  "response",
  d,
  sp,
  model = "scheffe_quadratic"
)
```

Also create a design evaluation and optimum:

```r
des <- mix_design(
  sp,
  type = "simplex_lattice",
  degree = 3
)

E <- mix_design_eval(
  des,
  model = "scheffe_quadratic"
)

op <- mix_optimize(
  fit,
  "maximize",
  method = "hybrid",
  seed = 32002
)
```

These objects will support the graphic families below.

---

# Part II. Design graphics

## 5. Ternary design plot

```r
mix_plot(
  des,
  type = "design",
  engine = "ggplot2"
)
```

A design plot should answer:

- Which formulations are tested?
- Are vertices represented?
- Are edges represented?
- Is the interior represented?
- Are replicates distinguishable if needed?
- Is the feasible subregion visible for constrained designs?

### Publication advice

Use clear component labels and avoid unnecessary decorative backgrounds. For a constrained region, do not let the full triangle visually imply that the entire simplex is admissible.

---

## 6. Extreme-vertices region plot

```r
sp_c <- mix_spec(
  c("A", "B", "C"),
  lower = c(0.10, 0.05, 0.05),
  upper = c(0.70, 0.80, 0.80),
  A = matrix(c(1, 1, 0), nrow = 1),
  b = 0.75,
  dir = "<="
)

D_c <- mix_design(
  sp_c,
  type = "extreme_vertices",
  include_centroid = TRUE,
  edge_midpoints = TRUE
)

mix_plot(D_c, "design")
```

The outer ternary frame is a coordinate system. The scientific region is the constrained polygon inside it.

---

# Part III. Ternary response surfaces

## 7. Contour lines

```r
mix_plot(
  fit,
  type = "ternary_contour",
  resolution = 50
)
```

Contours are effective for reading response values because equal-response curves can be followed directly.

### Good use

- locate high/low response regions;
- show saddle-like behavior;
- compare model slices;
- overlay design support.

---

## 8. Filled contours

```r
mix_plot(
  fit,
  type = "ternary_filled",
  resolution = 50
)
```

Filled contours improve pattern recognition but require a clearly labeled response scale.

Avoid a palette that implies sharp categorical boundaries in a continuous response unless the bins themselves have scientific meaning.

---

## 9. Heat-map style display

```r
mix_plot(
  fit,
  type = "heatmap",
  resolution = 50
)
```

Use heat-map displays for dense teaching or dashboard contexts, but preserve the simplex geometry and numeric legend.

---

# Part IV. Prediction uncertainty graphics

## 10. Prediction-variance map

```r
mix_plot(
  fit,
  type = "prediction_variance",
  resolution = 50
)
```

A response surface answers **what the model predicts**. A prediction-variance surface answers **where the model is well or poorly supported**.

Display them as separate figures when uncertainty is important.

### Interpretation

A region with a high predicted response and high prediction variance is not equivalent to a high-response region with low uncertainty.

---

## 11. Design-evaluation prediction variance

```r
mix_plot(
  E,
  type = "prediction_variance"
)
```

This view is especially useful before data collection because it evaluates design information without observed outcomes.

---

# Part V. Diagnostic graphics

## 12. Residuals versus fitted

```r
mix_plot(
  fit,
  type = "residuals"
)
```

Look for:

- curvature not represented by the model;
- funnel-shaped variability;
- isolated large residuals;
- response-dependent variance.

---

## 13. Normal Q-Q plot

```r
mix_plot(
  fit,
  type = "qq"
)
```

For Gaussian models, use the Q-Q plot as one diagnostic among several. Small samples can make tails difficult to judge.

---

## 14. Leverage view

```r
mix_plot(
  fit,
  type = "leverage"
)
```

High-leverage points in mixture designs often occur at boundaries. They may be expected, but their influence should be understood.

A leverage plot should not become an automatic outlier-deletion tool.

---

# Part VI. Component-effect graphics

## 15. Cox trace

```r
eff <- mix_effects(
  fit,
  type = "cox",
  component = "A",
  n = 51
)

mix_plot(eff)
```

The figure must identify the path rule used to change the other components. Otherwise the phrase "effect of A" is ambiguous in a mixture.

---

## 16. Substitution path

```r
sub <- mix_effects(
  fit,
  type = "substitution",
  from_component = "A",
  to_component = "B",
  n = 51
)

mix_plot(sub)
```

This is often more interpretable for applied scientists because it corresponds to replacing one ingredient with another.

---

# Part VII. Design-quality graphics

## 17. FDS

```r
mix_plot(E, "fds")
```

When comparing designs, use the same variance scaling and evaluation region.

---

## 18. VDG

```r
mix_plot(E, "vdg")
```

VDG is most meaningful when the radial coordinate has a clear interpretation in the independent-coordinate system.

The full design theory belongs to Extended Vignette 25; here the emphasis is how to communicate the result.

---

# Part VIII. Optimum graphics

## 19. Exact and near-optimal region

```r
mix_plot(
  op,
  type = "optimum"
)
```

A good optimum plot distinguishes:

- exact fitted optimum;
- near-optimal cloud/region;
- feasible boundary;
- response contours.

Do not use a star symbol for the optimum without explaining whether it is the exact fitted maximum or a selected practical formulation.

---

## 20. Optimum uncertainty cloud

```r
ci <- mix_optimum_ci(
  op,
  method = "parametric",
  B = 500,
  seed = 32101
)

mix_plot(
  ci,
  type = "optimum_ci"
)
```

The cloud shows joint location uncertainty. Do not replace it with three independent error bars for A, B, and C.

---

# Part IX. Multiresponse graphics

## 21. Desirability surface

```r
md <- mix_demo_data("multiresponse", n_rep = 3, seed = 32201)

mf <- mix_multi_fit(
  c("quality", "cost", "stability"),
  md,
  sp,
  model = "scheffe_quadratic"
)

goals <- c(
  quality = "maximize",
  cost = "minimize",
  stability = "maximize"
)

settings <- list(
  quality = list(low = min(md$quality), high = max(md$quality)),
  cost = list(low = min(md$cost), high = max(md$cost)),
  stability = list(low = min(md$stability), high = max(md$stability))
)

mo <- mix_multiopt(
  mf,
  goals,
  settings,
  seed = 32202
)

mix_plot(mo, "desirability")
```

The figure is interpretable only when the desirability settings are reported.

---

## 22. Pareto plot

```r
mix_plot(mo, "pareto")
```

Label the response axes with units and objective direction.

A Pareto graphic should communicate trade-offs, not imply that every nondominated point is equally desirable.

---

# Part X. Cornell-style dual-view 3D surface

## 23. Why reconstruct this historical figure type?

Three-dimensional wireframe surfaces remain pedagogically valuable because they show the shape of a three-component response surface above the simplex.

`mixRSMflow` generates a **recalculated scientific analogue** of the dual-view 3D mixture surface style historically used in classical mixture literature. It does not embed scanned textbook artwork.

---

## 24. Vector PDF

```r
mix_plot(
  fit,
  type = "surface3d",
  engine = "base",
  resolution = 35,
  views = 2,
  file = "mixture_surface_dual_view.pdf",
  width = 8,
  height = 7
)
```

### Why PDF?

For line-based scientific surfaces, vector PDF preserves geometric lines and text without raster pixelation.

---

## 25. Vector SVG

```r
mix_plot(
  fit,
  type = "surface3d",
  engine = "base",
  resolution = 35,
  views = 2,
  file = "mixture_surface_dual_view.svg",
  width = 8,
  height = 7
)
```

SVG is useful for vector editing and web publication.

---

## 26. What to inspect in the 3D output

- both perspectives show the same surface;
- component labels are correct;
- surface boundary lies over the simplex;
- no disconnected mesh lines appear;
- high and low regions agree with the ternary contour;
- perspective does not reverse component orientation;
- response axis is labeled with units;
- the figure remains legible in grayscale if required.

---

# Part XI. High-resolution raster output

## 27. TIFF at 600 dpi

```r
mix_plot(
  fit,
  type = "ternary_contour",
  file = "ternary_contour_600dpi.tiff",
  width = 7,
  height = 6,
  dpi = 600
)
```

### PNG

```r
mix_plot(
  fit,
  type = "ternary_filled",
  file = "ternary_filled_600dpi.png",
  width = 7,
  height = 6,
  dpi = 600
)
```

### Raster rule

High dpi does not repair a poorly designed figure. Set physical dimensions, font sizes, line widths, and labels for the target publication size first.

---

# Part XII. Interactive Plotly graphics

## 28. Interactive surface

```r
if (requireNamespace("plotly", quietly = TRUE)) {
  mix_plot(
    fit,
    type = "surface3d",
    engine = "plotly",
    resolution = 30
  )
}
```

Useful interactions include:

- rotate;
- zoom;
- inspect exact mixture coordinates;
- inspect predicted response;
- teach simplex orientation.

---

## 29. Interactive design

```r
if (requireNamespace("plotly", quietly = TRUE)) {
  mix_plot(
    des,
    type = "design",
    engine = "plotly"
  )
}
```

Interactive graphics are supplementary. Preserve the underlying numeric design and predictions as ordinary R objects.

---

# Part XIII. A complete publication figure suite

## 30. Recommended five-figure set for a three-component analysis

For a scientific manuscript, a compact figure set could include:

1. experimental design and feasible region;
2. fitted ternary response contour with observed design points;
3. diagnostics panel or residual plot;
4. prediction-variance map or uncertainty figure;
5. optimum + near-optimal/uncertainty region.

The 3D surface can be used as a supplementary or pedagogical figure when it adds genuine understanding beyond the contour map.

---

## 31. Example export workflow

```r
fig_dir <- "figures"
dir.create(fig_dir, showWarnings = FALSE)

mix_plot(
  des,
  "design",
  file = file.path(fig_dir, "Figure_1_design.pdf")
)

mix_plot(
  fit,
  "ternary_contour",
  file = file.path(fig_dir, "Figure_2_response.pdf"),
  width = 7,
  height = 6
)

mix_plot(
  fit,
  "residuals",
  file = file.path(fig_dir, "Figure_3_residuals.pdf")
)

mix_plot(
  fit,
  "prediction_variance",
  file = file.path(fig_dir, "Figure_4_prediction_variance.pdf")
)

mix_plot(
  ci,
  "optimum_ci",
  file = file.path(fig_dir, "Figure_5_optimum_uncertainty.pdf")
)
```

---

# Part XIV. Accessibility and scientific honesty

## 32. Color

Use color to support interpretation, not as the only encoding.

Good practice:

- colorblind-accessible palettes;
- labeled contour lines when precise values matter;
- adequate contrast;
- grayscale checking if the journal may print figures without color.

---

## 33. Observed data

Whenever possible, show design points on or beside fitted surfaces.

This helps readers distinguish:

- interpolation supported by observations;
- large gaps in the design;
- boundary extrapolation.

---

## 34. Uncertainty

Do not present only the smooth fitted surface if uncertainty is scientifically consequential.

Possible complementary views:

- prediction-variance map;
- confidence bands on effect traces;
- optimum cloud;
- near-optimal region.

---

## 35. Axes and labels

Use real component names and units. `A`, `B`, and `C` are appropriate for teaching but insufficient for a publication figure unless defined prominently.

---

# Part XV. Common mistakes

## 36. Cropping away component labels

Check the exported file, not only the RStudio preview.

---

## 37. Showing predictions over impossible compositions

Respect the feasible region.

---

## 38. Using 3D perspective to exaggerate small differences

Pair with a contour map and numeric scale.

---

## 39. Hiding design points

Show them where possible.

---

## 40. Using only interactive graphics in a reproducible report

Archive static figures and numeric objects.

---

## 41. Interpreting color bins as statistical classes

They are graphical intervals unless formally defined otherwise.

---

# Part XVI. Function-selection guide

| Communication goal | Plot |
|:--|:--|
| Where were blends tested? | design |
| What does the fitted surface look like? | ternary contour/filled |
| Where is uncertainty high? | prediction variance |
| Is model residual behavior acceptable? | residuals/QQ/leverage |
| How does a component change along a path? | effect object plot |
| How good is the design globally? | FDS/VDG |
| Where is the best fitted blend? | optimum |
| How uncertain is optimum location? | optimum_ci |
| How do multiresponse goals trade off? | desirability/Pareto |
| Teaching curvature in 3D | surface3d |
| Exploration/hover/rotation | Plotly engine |

---

# Part XVII. Figure reporting checklist

- [ ] figure number and descriptive caption;
- [ ] real component names;
- [ ] units;
- [ ] mixture region identified;
- [ ] observed design points where helpful;
- [ ] model used to create fitted surface;
- [ ] process settings for mixture-process slices;
- [ ] uncertainty definition;
- [ ] color scale label;
- [ ] vector format when appropriate;
- [ ] raster dpi and physical dimensions if raster;
- [ ] no clipping;
- [ ] accessible colors;
- [ ] consistency between 3D and contour views;
- [ ] static archive for any interactive graphic;
- [ ] reproducible code and package version.

---

# Appendix A. Compact graphics script

```r
library(mixRSMflow)

sp <- mix_spec(c("A", "B", "C"))
d <- mix_demo_data("mixture", n_rep = 3, seed = 20260813)
fit <- mix_fit("response", d, sp, "scheffe_quadratic")

mix_plot(fit, "ternary_contour", file = "contour.pdf")
mix_plot(fit, "ternary_filled", file = "filled.pdf")
mix_plot(fit, "prediction_variance", file = "variance.pdf")
mix_plot(fit, "surface3d", engine = "base", views = 2,
         file = "surface.pdf", width = 8, height = 7)

op <- mix_optimize(fit, "maximize", seed = 20260813)
ci <- mix_optimum_ci(op, B = 500, seed = 20260814)

mix_plot(op, "optimum", file = "optimum.pdf")
mix_plot(ci, "optimum_ci", file = "optimum_ci.pdf")
```

---

# Appendix B. Boundary with other extended vignettes

This vignette owns **how results are visualized and exported**. Statistical theory behind constrained geometry (24), optimal design (25), models (26/31), multiresponse decisions (28), optimum uncertainty (29), sequential experimentation (30), and software validation (33) is referenced rather than duplicated.

---

# Final perspective

A high-quality mixture figure should make the scientific geometry more visible, not less visible.

A strong communication sequence is:

**design support -> fitted surface -> diagnostic adequacy -> uncertainty -> optimum/trade-off -> publication export.**


---

# Appendix C. Advanced graphics laboratories

## C1. Laboratory: figure consistency audit

Generate:

1. ternary contour;
2. filled contour;
3. 3D surface;
4. direct prediction table on a grid.

Select five compositions and verify that the response ordering is consistent across all four representations.

### Lesson

Different graphic engines should communicate the same numeric surface. A perspective or palette should never reverse scientific interpretation.

---

## C2. Laboratory: design support overlay

Create a sparse design and a dense design fitted to the same synthetic surface. Plot fitted contours with observed design points.

Discuss how the same smooth contour can look equally convincing even when one design has much weaker support. Then add a prediction-variance map.

### Lesson

Design points and uncertainty protect against the visual illusion of uniformly supported interpolation.

---

## C3. Laboratory: vector versus raster

Export the same contour as PDF, SVG, PNG 300 dpi, and TIFF 600 dpi. Zoom to 800% and compare lines and text.

Record:

- file size;
- physical dimensions;
- visual sharpness;
- journal suitability;
- editability.

---

## C4. Laboratory: accessible palette check

Render the figure in color, grayscale, and a color-vision-deficiency simulator if available. Ensure the scientific pattern can still be understood from contours, labels, and symbols.

---

# Appendix D. Graphics troubleshooting matrix

| Symptom | Likely issue | Response |
|:--|:--|:--|
| contour and 3D peak disagree | orientation/grid mismatch | verify predictions numerically |
| labels clipped in PDF | margins/device dimensions | increase dimensions/margins and re-export |
| raster text blurry | low physical resolution | set final dimensions + adequate dpi |
| SVG huge | overly dense surface grid | reduce resolution while preserving shape |
| Plotly works but static export differs | different engine rendering | treat numeric object as authority and validate both |
| color scale hides boundary | low contrast | add contours/labels and accessible palette |
| response appears outside feasible region | grid not constrained | regenerate using package feasible grid |
| observed points obscure contours | overplotting | adjust symbols/transparency without removing data support |

---

# Appendix E. Guided graphics exercises

### Exercise 1. Caption completeness

Write a caption for a ternary contour including response, model, units, design points, and process settings.

### Exercise 2. Prediction variance

Explain why a prediction-variance map belongs beside a response surface in a sparse constrained design.

### Exercise 3. Two-view 3D

Explain what the second perspective contributes and why the ternary contour remains necessary.

### Exercise 4. Journal export

Prepare one vector PDF and one 600-dpi TIFF at final publication size. Compare file metadata.

### Exercise 5. Grayscale

Design a figure that remains interpretable when color is removed.

### Exercise 6. Process slices

Create two ternary surfaces at different temperatures and use the same response scale so the panels are visually comparable.

### Exercise 7. Near-optimal display

Distinguish exact optimum, near-optimal region, and optimum uncertainty cloud using different symbols/line types without implying false categories.

### Exercise 8. Pareto labeling

Label three practically interesting Pareto solutions without overcrowding the plot.

### Exercise 9. Residual figure

Explain why residuals versus fitted should not be shown as a ternary map by default.

### Exercise 10. Interactive archive

Save the numeric predictions underlying an interactive Plotly surface so the analysis can be reproduced without the browser widget.

### Exercise 11. Accessibility

Replace component labels A/B/C with real agronomic names and units. Check whether the figure remains legible at 85-mm journal width.

### Exercise 12. Reviewer exercise

A paper shows a smooth ternary heat map with no design points, model name, or uncertainty. Draft a reviewer comment requesting the missing evidence.

---

# Appendix F. Reviewer-style figure audit

Verify:

1. component labels and units;
2. feasible region;
3. observed design support;
4. model/smoothing source;
5. prediction versus raw data distinction;
6. uncertainty where relevant;
7. process settings for slices;
8. consistent scales across panels;
9. nonmisleading perspective;
10. accessible colors;
11. vector/raster quality;
12. caption sufficient for independent interpretation;
13. reproducible code/object;
14. no copied protected artwork.

---

# Appendix G. Caption templates

### Ternary response contour

> Predicted [response, unit] from the fitted [model] over the feasible three-component mixture region. Points denote observed experimental formulations; contour lines represent equal fitted response. Predictions are restricted to the declared component bounds.

### Prediction variance

> Model-based prediction variance over the feasible mixture region for the fitted [model]. Lower values indicate greater design-supported precision; the map describes uncertainty of the fitted mean structure rather than observed response magnitude.

### Dual-view 3D surface

> Two vector-rendered perspectives of the fitted three-component response surface recalculated from the model predictions. The dual view is provided for geometric interpretation and is accompanied by the ternary contour for precise composition reading.

### Optimum uncertainty

> Joint distribution of reoptimized mixture compositions from repeated surface perturbations. The marker denotes the fitted optimum, while the cloud represents uncertainty in optimum location under the stated procedure.


---

# Appendix H. Applied figure case bank

## H1. Journal response-surface figure

For a three-component fertilizer paper, use a vector ternary contour as the main response figure. Overlay design points, label component names/units, and state the fitted model in the caption. Add a separate prediction-variance panel if design support is uneven. The 3D dual-view surface can appear in supplementary material if it adds intuitive curvature information.

## H2. Constrained formulation figure

For a pesticide mixture with a combined-active ceiling, display the feasible polygon clearly inside the ternary coordinate frame. Do not fill the entire triangle with predictions. A reader should be able to see immediately which compositions were impossible or disallowed.

## H3. Mixture-process figure set

When temperature modifies the blending response, plot separate ternary surfaces at low, medium, and high temperature using identical response limits. This allows direct visual comparison. Captions should state every fixed process setting.

## H4. Optimum decision graphic

Combine response contours with the exact optimum, near-optimal region, and a separate optimum-uncertainty cloud. Use visual encodings that distinguish “nearly as good” from “statistically plausible optimum location.” They are different concepts and should not share one unlabeled shaded region.

## H5. Interactive teaching view

Use Plotly for classroom rotation and hover inspection, but archive the numeric prediction grid and a static PDF. An interactive widget is a presentation layer, not the sole scientific record.

---

# Appendix I. Short-answer graphics review

1. **Why show design points?** To reveal empirical support for interpolation.
2. **Why pair 3D with contours?** Perspective shows shape; contours support precise composition reading.
3. **What does prediction variance show?** Model/design uncertainty, not response magnitude.
4. **Why prefer vector output?** Scalable lines/text for publication.
5. **When use 600-dpi raster?** When a journal or graphic type requires raster output.
6. **Why use common scales across process slices?** To avoid visual distortion of differences.
7. **What should every color map include?** Numeric legend and units.
8. **Why archive numeric grids?** To make graphics reproducible independently of rendering engine.
9. **What is an accessibility safeguard?** Do not encode meaning only through color.
10. **What must a historical-style figure avoid?** Copying protected artwork; recalculate from the fitted model.


---

# Appendix J. Deeper conceptual notes on visual inference

## J1. Interpolation density is not information density

A contour can be rendered at thousands of grid points even when the experiment has ten unique blends. Rendering resolution improves visual smoothness, not experimental information. Show design points and, where useful, prediction variance so readers do not confuse pixel density with data density.

## J2. Common scales are required for visual comparison

When comparing surfaces across treatments or process settings, use the same response limits whenever the scientific question concerns magnitude differences. Auto-scaling each panel can make small and large effects appear equally dramatic. If different scales are unavoidable, state that clearly.

## J3. Perspective can distort relative importance

3D surfaces can make front edges appear visually dominant and can hide valleys behind peaks. The dual-view design reduces but does not eliminate perspective problems. A ternary contour remains the preferred companion for quantitative reading.

## J4. Uncertainty should be a first-class graphic

A fitted surface without uncertainty can encourage overly precise decisions. Prediction-variance maps, confidence bands, and optimum clouds should be considered part of the main evidence when recommendations depend on poorly supported regions.

## J5. Figure provenance

For publication-quality reproducibility, archive the R object used to create the figure, the plotting call, the exported file, and the package/session versions. If a figure is later edited externally, preserve both the original statistical export and the edited publication artifact.
