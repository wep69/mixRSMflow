# mixRSMflow: Constrained Mixture Geometry, Pseudocomponents, and Feasible Regions

**Extended instructional vignette**  
**Package:** `mixRSMflow`  
**Version targeted:** `0.1.0.9000`  
**Extended vignette:** 24  
**Format:** Markdown source only  
**Primary ownership:** mixture geometry, constraints, transformations, pseudocomponents, extreme vertices, major/minor and categorized component geometry  
**Companion material:** `23-foundations-to-advanced-tutorial-mixRSMflow.md`, `02-mixture-geometry.Rmd`, `04-constrained-regions.Rmd`

> This document is intentionally supplied as `.md`. It is designed as an extended teaching monograph and is not a rebuilt package vignette. Code should be run locally with the package version stated above.

> **Scope boundary.** This extended vignette owns the topic named in its title. Closely related methods that belong to another extended vignette are referenced rather than re-taught. This separation is deliberate so that the extended documentation remains deep without becoming repetitive.

---

## 1. Why geometry is the first scientific decision

In an ordinary response-surface experiment, several quantitative factors may vary independently inside a box, sphere, or other experimental region. A mixture experiment is different because the component amounts are linked by a total. If the components are proportions,

\[
x_i \ge 0,\qquad \sum_{i=1}^q x_i = 1.
\]

If percentages are used, the same geometry is scaled to a total of 100. The crucial fact is not the number 1 or 100. The crucial fact is that **only `q - 1` coordinates are independent**.

This changes design, modeling, interpretation, and optimization. A researcher cannot increase one mixture component while keeping every other component fixed. At least one other component must decrease. Consequently, the experimental region is not an ordinary factorial cube. For three components, the unconstrained region is a triangle. For four components, it is a tetrahedron. For more components, it is a higher-dimensional simplex.

`mixRSMflow` therefore starts with `mix_spec()` rather than with a modeling function.

---

## 2. Learning objectives

After this vignette, the reader should be able to:

1. define a full or constrained mixture system reproducibly;
2. explain the fixed-sum dependence among component coordinates;
3. validate lower and upper bounds before design generation;
4. encode general linear inequalities and equalities;
5. enumerate and interpret extreme vertices of a feasible polytope;
6. distinguish the unrestricted simplex from the actual feasible region;
7. transform proportions to orthonormal independent coordinates and back;
8. define spherical, ellipsoidal, and cuboidal local regions in the independent-coordinate system;
9. use lower-bound and upper-bound pseudocomponents and invert the transformation;
10. reparameterize a fitted mixture model through a slack component when scientifically useful;
11. construct major/minor multiple-lattice geometries;
12. create categorized-component designs without confusing grouped geometry with unsupported historical coefficient transformations;
13. recognize nearly degenerate regions before fitting unstable models;
14. prepare a geometry object that can be handed to the optimal-design workflow without redefining the science.

---

## 3. Function map for this vignette

| Task | Primary function | Output |
|:--|:--|:--|
| Declare components and constraints | `mix_spec()` | `mix_spec` |
| Add a local region of interest | `mix_region()` | `mix_region` |
| Enumerate feasible extreme vertices | `mix_vertices()` | vertex data frame |
| Map to `q-1` independent coordinates | `mix_transform()` | numeric/data-frame coordinates |
| Return to original proportions | `mix_inverse_transform()` | original mixture coordinates |
| Transform lower/upper bounded systems | `mix_pseudocomponents()` | L/U pseudocomponents |
| Choose a slack component | `mix_reparameterize()` | reparameterized fit |
| Major/minor component lattices | `mix_multiple_lattice()` | `mix_design` |
| Categorized components | `mix_categorized_design()` | `mix_design` |
| Visual inspection | `mix_plot()` | static or optional interactive graphic |
| Record provenance | `mix_audit_trail()` | audit table |

This vignette stops before optimality-criterion theory. Once the feasible region is defined, see Extended Vignette 25 for D-, A-, I-, G-, E-, T-, Alias-, Bayesian, GA, FDS, VDG, IMSE, and rotatability workflows.

---

# Part I. Full-simplex foundations

## 4. A three-component agronomic formulation

Suppose a substrate formulation contains:

- `Compost`;
- `Biochar`;
- `Mineral` carrier.

Create the unrestricted system:

```r
library(mixRSMflow)

sp_full <- mix_spec(
  components = c("Compost", "Biochar", "Mineral"),
  total = 1,
  units = "proportion"
)

sp_full
```

The object stores the component names, the total, default bounds, numerical tolerance, independent-coordinate basis, feasible center, and an audit record.

### 4.1 Why store the region in an object?

A script that repeatedly writes constraints by hand is vulnerable to silent inconsistency. One analysis may use `Biochar <= 0.30`, another `Biochar <= 0.35`, and a third may forget the restriction entirely. A `mix_spec` object makes the region an explicit scientific object that is passed to design, modeling, prediction, and optimization functions.

### 4.2 Inspect the provenance

```r
mix_audit_trail(sp_full)
```

The audit trail is not a substitute for an electronic laboratory notebook. It is an internal record of package-level choices.

---

## 5. The simplex as a coordinate system

For three components, a point such as

```r
x <- data.frame(
  Compost = 0.40,
  Biochar = 0.20,
  Mineral = 0.40
)
```

satisfies

\[
0.40+0.20+0.40=1.
\]

Changing compost to 0.50 requires a compensating change in biochar, mineral carrier, or both.

This is why an ordinary coefficient interpretation such as "the effect of a one-unit increase in Compost while all other predictors are held constant" does not describe an admissible movement in the formulation region.

The component-effect functions are treated in the master tutorial and focused component-effects vignette. Here the concern is the geometry that makes those paths necessary.

---

## 6. Four components and higher-dimensional simplices

```r
sp4 <- mix_spec(
  c("Compost", "Biochar", "Mineral", "Fiber")
)
```

A four-component full simplex is a tetrahedron. With five or more components, no ordinary 2D or 3D plot can display the complete geometry without projection, slicing, or profile views.

The absence of a visually simple simplex does not change the mathematics. The fixed-sum dimension remains `q - 1`.

### Practical consequence

As `q` grows, blindly generating a dense lattice becomes expensive. Constraint handling, candidate-set generation, and model dimension should be considered before a high-degree design is requested.

---

# Part II. Bounds and general restrictions

## 7. Lower bounds

Agronomic formulations rarely permit all components to reach zero. Suppose every substrate must contain at least:

- 20% compost;
- 5% biochar;
- 10% mineral carrier.

```r
sp_lower <- mix_spec(
  c("Compost", "Biochar", "Mineral"),
  lower = c(0.20, 0.05, 0.10)
)
```

The lower bounds consume 0.35 of the total. Therefore 0.65 remains free for redistribution.

A basic feasibility identity is

\[
\sum_i L_i \le 1.
\]

If the sum of lower bounds exceeds the total, no formulation can satisfy the declared system.

---

## 8. Upper bounds

Suppose biochar cannot exceed 35% because of pH or conductivity considerations:

```r
sp_upper <- mix_spec(
  c("Compost", "Biochar", "Mineral"),
  upper = c(0.80, 0.35, 0.80)
)
```

A necessary feasibility condition is

\[
\sum_i U_i \ge 1.
\]

This condition is necessary but may not be sufficient when additional linear constraints are present.

---

## 9. Simultaneous lower and upper bounds

```r
sp_bounded <- mix_spec(
  components = c("Compost", "Biochar", "Mineral"),
  lower = c(0.20, 0.05, 0.10),
  upper = c(0.70, 0.35, 0.60)
)
```

Before designing an experiment, ask whether the upper and lower bounds reflect:

- safety or regulatory requirements;
- material availability;
- agronomic plausibility;
- equipment limits;
- prior knowledge;
- or an arbitrary choice made to simplify the experiment.

Artificially narrow bounds can create severe model conditioning problems and can hide the shape of the response surface.

---

## 10. General linear inequalities

Suppose compost and biochar together may not exceed 0.80.

\[
x_{Compost}+x_{Biochar}\le0.80.
\]

Encode the restriction as:

```r
A <- matrix(
  c(1, 1, 0),
  nrow = 1,
  byrow = TRUE
)

sp_linear <- mix_spec(
  components = c("Compost", "Biochar", "Mineral"),
  lower = c(0.20, 0.05, 0.10),
  upper = c(0.70, 0.35, 0.60),
  A = A,
  b = 0.80,
  dir = "<="
)
```

The matrix `A` contains one row per declared restriction and `b` contains the corresponding right-hand sides.

### 10.1 Several restrictions

For example:

\[
\begin{aligned}
Compost + Biochar &\le 0.80,\\
Biochar + Mineral &\ge 0.30.
\end{aligned}
\]

```r
A2 <- rbind(
  c(1, 1, 0),
  c(0, 1, 1)
)

sp_multi_constraint <- mix_spec(
  components = c("Compost", "Biochar", "Mineral"),
  lower = c(0.20, 0.05, 0.10),
  upper = c(0.70, 0.35, 0.60),
  A = A2,
  b = c(0.80, 0.30),
  dir = c("<=", ">=")
)
```

### Reporting rule

Publish the constraints in the original scientific units, not only as an internal matrix.

---

## 11. Equality constraints

Some formulations contain balance identities beyond the total. For example, a grouped nutrient fraction might be fixed by a manufacturing specification.

```r
sp_eq <- mix_spec(
  c("A", "B", "C", "D"),
  A = matrix(c(1, 1, 0, 0), nrow = 1),
  b = 0.50,
  dir = "=="
)
```

An equality can reduce the effective dimension of the feasible region further. If too many independent equalities are added, the region can collapse to a line, a point, or an empty set.

---

# Part III. Extreme vertices and feasible polytopes

## 12. Enumerate extreme vertices

```r
V <- mix_vertices(sp_linear)
V
```

For a convex polytope, the vertices define its corners. In a constrained mixture experiment they are important because:

- they reveal the actual region shape;
- some design algorithms draw candidates from the boundary;
- a seemingly mild set of bounds can produce a narrow irregular polygon;
- extreme-vertices designs begin from these corners;
- optimization results often occur on a boundary.

### 12.1 Verify numerically

```r
stopifnot(
  all(abs(rowSums(V) - 1) < 1e-7),
  all(V$Compost >= 0.20 - 1e-7),
  all(V$Biochar >= 0.05 - 1e-7),
  all(V$Mineral >= 0.10 - 1e-7),
  all(V$Compost + V$Biochar <= 0.80 + 1e-7)
)
```

This type of invariant check is valuable in local validation and custom preprocessing.

---

## 13. Active constraints and geometric meaning

A vertex typically occurs where enough constraints become active simultaneously. In three components, the sum constraint plus two independent active bounds or inequalities can define a corner.

Scientific interpretation should ask what creates each corner:

- minimum biochar plus maximum compost;
- minimum compost plus the combined organic-matter limit;
- maximum mineral carrier plus another bound;
- or an intersection of two general inequalities.

Understanding the active constraints is useful when a predicted optimum lands on a corner. The optimum may be driven by the imposed feasibility rule as much as by the fitted response surface.

---

## 14. Extreme-vertices design as a geometric inspection tool

```r
ev <- mix_design(
  sp_linear,
  type = "extreme_vertices",
  include_centroid = TRUE,
  edge_midpoints = TRUE
)

mix_plot(ev, type = "design")
```

The design includes the boundary geometry and optional interior support. It is useful as a first look at the constrained region.

It is **not** automatically the best design for parameter precision or prediction. That question belongs to Extended Vignette 25.

---

## 15. Thin, narrow, and nearly degenerate regions

A feasible region can be mathematically nonempty but statistically problematic.

Examples include:

- one component restricted to a range of only 0.01;
- two strong inequalities that leave a very thin strip;
- four components with two nearly redundant equality constraints;
- a region whose vertices are numerically almost collinear.

Consequences include:

- near-rank deficiency;
- large condition numbers;
- highly correlated parameter estimates;
- unstable high-order terms;
- unreliable boundary extrapolation.

### Recommended workflow

1. inspect vertices;
2. transform to independent coordinates;
3. inspect spread in each independent direction;
4. choose the simplest scientifically adequate model;
5. evaluate candidate designs using prediction variance and conditioning;
6. augment the region only if the scientific formulation constraints truly permit it.

Do not widen a safety or biological constraint merely to improve numerical conditioning.

---

# Part IV. Independent-coordinate transformations

## 16. Why transform to `q - 1` coordinates?

The original components contain one exact linear dependence. An orthonormal contrast basis spans the subspace perpendicular to the vector of ones.

For a center `c` and basis `H`, `mixRSMflow` uses

\[
z=(x-c)H,
\]

with inverse

\[
x=c+zH^T.
\]

```r
sp <- mix_spec(c("A", "B", "C"))

x <- data.frame(
  A = c(0.20, 0.50),
  B = c(0.35, 0.20),
  C = c(0.45, 0.30)
)

z <- mix_transform(x, sp)
z

x_back <- mix_inverse_transform(z, sp)
x_back
```

### Numerical verification

```r
max(abs(as.matrix(x) - as.matrix(x_back)))
```

The result should be near numerical precision for admissible inputs.

---

## 17. Changing the transformation center

```r
center <- c(A = 0.40, B = 0.25, C = 0.35)

z2 <- mix_transform(
  x,
  sp,
  center = center
)
```

A local center can be scientifically meaningful when a current commercial or agronomic formulation is the reference point.

However, changing coordinates does not change which original mixtures are feasible.

---

# Part V. Local regions of interest

## 18. Polytope region

```r
rg_poly <- mix_region(
  sp_linear,
  type = "polytope"
)
```

This keeps the constraints directly in original mixture space.

---

## 19. Spherical region in independent coordinates

Suppose a researcher wants to study only a neighborhood around the center:

```r
sp_center <- mix_spec(c("A", "B", "C"))

rg_sphere <- mix_region(
  sp_center,
  type = "sphere",
  radius = 0.15
)
```

The sphere is defined in the independent-coordinate system, then mapped back to the mixture geometry.

This can support local response-surface designs without pretending the three proportions vary independently.

---

## 20. Ellipsoidal region

If scientific prior information suggests different allowable movement along the two independent directions:

```r
shape <- matrix(
  c(
    1.00, 0.20,
    0.20, 0.50
  ),
  nrow = 2,
  byrow = TRUE
)

rg_ell <- mix_region(
  sp_center,
  type = "ellipsoid",
  shape = shape
)
```

An ellipsoid can encode directional asymmetry in the local region of interest.

---

## 21. Cuboidal region

```r
rg_box <- mix_region(
  sp_center,
  type = "cuboid",
  lower_y = c(-0.15, -0.08),
  upper_y = c( 0.12,  0.10)
)
```

A cuboid in independent coordinates can be convenient when operational process windows are naturally described by independent contrasts.

### Reporting caution

Always translate the final experimental points back to original component proportions. Independent coordinates are a mathematical working system, not the formulation recipe.

---

# Part VI. Pseudocomponents

## 22. Lower-bound pseudocomponents

Let lower bounds be `L_i`. Define

\[
L_+=\sum_i L_i,
\]

and for a feasible original mixture,

\[
z_i=\frac{x_i-L_i}{1-L_+}.
\]

Then the `z_i` sum to one.

```r
sp_L <- mix_spec(
  c("A", "B", "C"),
  lower = c(0.10, 0.20, 0.10)
)

xL <- data.frame(
  A = c(0.20, 0.40),
  B = c(0.30, 0.20),
  C = c(0.50, 0.40)
)

zL <- mix_pseudocomponents(
  xL,
  sp_L,
  type = "L"
)

zL
```

Invert:

```r
mix_pseudocomponents(
  zL,
  sp_L,
  type = "L",
  inverse = TRUE
)
```

### Interpretation

L-pseudocomponents remove mandatory minimum amounts from the coordinate system. They do not remove the minimum requirements from the real formulation.

---

## 23. Upper-bound pseudocomponents

```r
sp_U <- mix_spec(
  c("A", "B", "C"),
  upper = c(0.70, 0.70, 0.70)
)

xU <- data.frame(
  A = c(0.30, 0.40),
  B = c(0.30, 0.20),
  C = c(0.40, 0.40)
)

zU <- mix_pseudocomponents(
  xU,
  sp_U,
  type = "U"
)

zU
```

Invert:

```r
mix_pseudocomponents(
  zU,
  sp_U,
  type = "U",
  inverse = TRUE
)
```

### When to avoid pseudocomponents

Do not use a transformed coordinate system merely to make a figure look more regular. Use it when it improves a specific design or modeling argument and retain the original-scale results for scientific communication.

---

# Part VII. Slack-variable parameterization

## 24. What a slack component means

Because one component is determined by the total,

\[
x_q=1-\sum_{i=1}^{q-1}x_i.
\]

A model can therefore be reexpressed with one component serving as the slack variable.

```r
sp <- mix_spec(c("A", "B", "C"))
d <- mix_demo_data("mixture", n_rep = 3, seed = 24001)
fit <- mix_fit("response", d, sp, "scheffe_quadratic")

fit_slack <- mix_reparameterize(
  fit,
  slack_component = "C"
)

fit_slack
```

### Interpretation

Changing the slack component changes the coefficient parameterization but should not change fitted values for the same underlying model space.

Use the parameterization that best supports the scientific explanation, not the one that produces the most convenient coefficient signs.

---

# Part VIII. Major/minor and categorized component geometries

## 25. Major and minor components

Many agronomic formulations contain major ingredients that account for most of the total and minor additives that occupy a small fraction.

```r
sp5 <- mix_spec(
  c("Base1", "Base2", "Additive1", "Additive2", "Additive3")
)

ml <- mix_multiple_lattice(
  sp5,
  major = c("Base1", "Base2"),
  minor = c("Additive1", "Additive2", "Additive3"),
  major_totals = c(0.80, 0.90),
  major_degree = 3,
  minor_degree = 2,
  seed = 25001
)

ml
```

The function constructs several lattice structures while respecting the major-component total.

### Scientific use

Examples include:

- two bulk substrate materials plus micronutrient carriers;
- base oil fractions plus small adjuvant fractions;
- protein/energy bases plus microingredients;
- carrier materials plus biological additives.

---

## 26. Categorized components

Suppose five components belong to two scientifically meaningful categories.

```r
categories <- list(
  organic = c("CompostA", "CompostB"),
  mineral = c("MineralA", "MineralB", "MineralC")
)

sp_cat <- mix_spec(unlist(categories, use.names = FALSE))

cd <- mix_categorized_design(
  sp_cat,
  categories = categories,
  between_degree = 2,
  within_degree = 2,
  category_totals = c(organic = 0.60, mineral = 0.40),
  seed = 26001
)

cd
```

### Method gate

The package implements the grouped design geometry. Historical coefficient-transformation formulas for specific categorized-component models are not silently claimed unless they are explicitly implemented and validated. Consult `inst/METHOD_GATES.md` before presenting a historical transformation as a reproduced package feature.

This distinction is important: **a design geometry can be implemented correctly even when a specialized historical coefficient mapping remains outside the current validated scope.**

---

# Part IX. Mixture of mixtures as a hierarchical formulation concept

## 27. Conceptual structure

A mixture of mixtures occurs when one or more components are themselves sub-mixtures. For example:

1. an organic base is prepared from compost types;
2. a mineral base is prepared from mineral carriers;
3. the two sub-mixtures are then combined at a higher level.

The geometry has two scales:

- within-submixture proportions;
- between-submixture totals.

The current package supports design structures that can be assembled from grouped/categorized and major/minor constructions. The complete scientific interpretation should preserve both levels rather than flattening every ingredient into an undifferentiated list.

---

# Part X. A complete agronomic constrained-region workflow

## 28. Scientific problem

A nursery experiment will optimize a substrate consisting of:

- compost `C`;
- biochar `B`;
- mineral carrier `M`.

Requirements:

\[
0.20 \le C \le 0.70,
\]

\[
0.05 \le B \le 0.35,
\]

\[
0.10 \le M \le 0.60,
\]

\[
C+B\le0.80.
\]

### Step 1: create the reproducible specification

```r
sp <- mix_spec(
  c("C", "B", "M"),
  lower = c(0.20, 0.05, 0.10),
  upper = c(0.70, 0.35, 0.60),
  A = matrix(c(1, 1, 0), nrow = 1),
  b = 0.80,
  dir = "<="
)
```

### Step 2: enumerate the vertices

```r
V <- mix_vertices(sp)
V
```

### Step 3: check invariants

```r
stopifnot(
  all(abs(rowSums(V) - 1) < 1e-7),
  all(V$C >= 0.20 - 1e-7),
  all(V$B >= 0.05 - 1e-7),
  all(V$M >= 0.10 - 1e-7),
  all(V$C <= 0.70 + 1e-7),
  all(V$B <= 0.35 + 1e-7),
  all(V$M <= 0.60 + 1e-7),
  all(V$C + V$B <= 0.80 + 1e-7)
)
```

### Step 4: inspect an extreme-vertices design

```r
d0 <- mix_design(
  sp,
  type = "extreme_vertices",
  include_centroid = TRUE,
  edge_midpoints = TRUE
)

mix_plot(d0, type = "design")
```

### Step 5: transform to independent coordinates

```r
Z <- mix_transform(V, sp)
Z
```

Check whether one direction is almost unrepresented. This can reveal a very thin feasible region.

### Step 6: store the geometry for the next workflow

```r
saveRDS(
  sp,
  file = "substrate_mixture_spec.rds"
)
```

The next scientific decision is not to fit a response model. No response has been collected yet. The next decision is to choose an experimental design that provides adequate information for the intended model. That topic belongs to Extended Vignette 25.

---

# Part XI. Common mistakes

## 29. Specifying bounds that cannot sum to the total

Check:

\[
\sum L_i\le T\le\sum U_i.
\]

Then check all additional constraints.

---

## 30. Plotting the full simplex after imposing constraints

A ternary triangle can remain a useful coordinate frame, but visually distinguish the admissible subregion. Do not imply that predictions or experimental support cover the entire triangle.

---

## 31. Assuming every extreme vertex should be tested

Extreme vertices define geometry. The optimal set of experimental runs depends on the intended model and criterion.

See Extended Vignette 25.

---

## 32. Treating pseudocomponents as the final formulation

Always translate final recipes back to the original components.

---

## 33. Adding constraints after observing outcomes

Post-outcome restriction of the design region can introduce selective interpretation. Feasibility constraints should be defined from scientific, operational, safety, or economic knowledge whenever possible before response analysis.

---

## 34. Ignoring units

If one dataset records proportions and another percentages, a valid mixture can appear invalid numerically. Use `total` and `units` consistently and document any conversion.

---

## 35. Assuming a nonempty region is informative enough

A region can be feasible but nearly degenerate. Evaluate spread and design quality before committing resources.

---

# Part XII. Function-selection guide

| Question | Function | Why |
|:--|:--|:--|
| What are my components and bounds? | `mix_spec()` | authoritative mixture definition |
| Do I have a local spherical/ellipsoidal/cuboidal region? | `mix_region()` | region in independent coordinates |
| Where are the constrained corners? | `mix_vertices()` | extreme-vertex enumeration |
| I need independent coordinates | `mix_transform()` | maps to `q-1` dimensions |
| I need original proportions again | `mix_inverse_transform()` | reverses the transformation |
| I have only lower bounds | `mix_pseudocomponents(type="L")` | lower-bound pseudocomponents |
| I have upper bounds | `mix_pseudocomponents(type="U")` | upper-bound pseudocomponents |
| One component is a natural remainder | `mix_reparameterize()` | slack-variable representation |
| I have major and minor groups | `mix_multiple_lattice()` | multiple-lattice geometry |
| Components belong to categories | `mix_categorized_design()` | grouped component design |
| I need the design criterion | Extended Vignette 25 | avoids duplicating optimal-design theory here |

---

# Part XIII. Minimum geometry reporting checklist

Before a mixture experiment is designed, document:

- [ ] component names;
- [ ] physical units;
- [ ] fixed total;
- [ ] lower bounds;
- [ ] upper bounds;
- [ ] general inequalities;
- [ ] equality restrictions;
- [ ] origin of each restriction;
- [ ] whether constraints were pre-specified;
- [ ] feasible extreme vertices;
- [ ] effective dimension;
- [ ] evidence of a narrow or nearly degenerate region;
- [ ] pseudocomponent transformation, if used;
- [ ] center of independent coordinates, if nondefault;
- [ ] local region shape, if sphere/ellipsoid/cuboid;
- [ ] major/minor or category grouping rules;
- [ ] versioned `mix_spec` object;
- [ ] audit trail;
- [ ] final formulation results translated back to original components.

---

# Appendix A. Minimal reusable script

```r
library(mixRSMflow)

sp <- mix_spec(
  c("A", "B", "C"),
  lower = c(0.10, 0.05, 0.05),
  upper = c(0.70, 0.80, 0.80),
  A = matrix(c(1, 1, 0), nrow = 1),
  b = 0.75,
  dir = "<="
)

V <- mix_vertices(sp)
print(V)

stopifnot(
  all(abs(rowSums(V) - 1) < 1e-7),
  all(V$A + V$B <= 0.75 + 1e-7)
)

Z <- mix_transform(V, sp)
print(Z)

V_back <- mix_inverse_transform(Z, sp)
print(V_back)

D0 <- mix_design(
  sp,
  "extreme_vertices",
  include_centroid = TRUE,
  edge_midpoints = TRUE
)

mix_plot(D0)
mix_audit_trail(D0)
```

---

# Appendix B. Boundary with the other extended vignettes

This vignette deliberately does **not** provide full treatments of:

- D/A/I/G/E/T/Alias/Bayesian optimality;
- FDS, VDG, IMSE, and genetic search;
- Scheffé and alternative response models;
- mixture-process experimental structures;
- response optimization;
- uncertainty of the optimum;
- multiple-response desirability;
- sequential Bayesian optimization;
- publication graphics beyond geometric inspection;
- package validation and release engineering.

Those topics are owned by Extended Vignettes 25 through 33.

---

# Final perspective

The feasible region is part of the scientific hypothesis. It is not a plotting convenience and not a minor preprocessing detail.

A rigorous mixture analysis begins by making the region explicit:

**components -> total -> bounds -> linear constraints -> extreme vertices -> independent-coordinate geometry -> design.**

Only after that sequence is defensible should model fitting and optimization begin.


---

# Appendix C. Advanced geometry laboratories

## C1. Laboratory: diagnose an almost-degenerate feasible region

### Objective

Learn to distinguish a region that is merely constrained from one that has too little geometric width to support a rich response surface.

```r
library(mixRSMflow)

sp_thin <- mix_spec(
  c("A", "B", "C"),
  lower = c(0.45, 0.45, 0.00),
  upper = c(0.55, 0.55, 0.10)
)

V_thin <- mix_vertices(sp_thin)
V_thin

Z_thin <- mix_transform(V_thin, sp_thin)
Z_thin
```

### Tasks

1. Confirm that every vertex sums to one.
2. Compute the range of every independent coordinate.
3. Compare those ranges with the full-simplex ranges.
4. Explain why a high-order model may be numerically estimable in theory yet scientifically fragile in this region.
5. Propose two design responses: simplify the model or, if scientifically allowed, broaden the formulation region.

### Interpretation

A thin feasible region is not an error. It may accurately represent a manufacturing or safety window. The correct response is not to relax constraints automatically. Instead, recognize that only limited directions of compositional change are experimentally available. This limits what the data can reveal about curvature and interactions.

---

## C2. Laboratory: compare original coordinates and L-pseudocomponents

```r
spL <- mix_spec(
  c("A", "B", "C"),
  lower = c(0.20, 0.10, 0.10)
)

X <- data.frame(
  A = c(0.20, 0.30, 0.50, 0.60),
  B = c(0.30, 0.30, 0.20, 0.10),
  C = c(0.50, 0.40, 0.30, 0.30)
)

Z <- mix_pseudocomponents(X, spL, type = "L")
Z

X_back <- mix_pseudocomponents(Z, spL, type = "L", inverse = TRUE)
X_back
```

### Tasks

- Verify that rows of `Z` sum to one.
- Explain why A = 0.20 becomes zero in the transformed system.
- Describe what a pure pseudocomponent point means in the original formulation.
- Write the transformation equation in the methods section using the actual lower bounds.

### Teaching point

Pseudocomponents can make a lower-bounded region look like a standard simplex, but the scientific formulation remains constrained. A vertex in pseudocomponent space does not necessarily correspond to a pure original ingredient.

---

## C3. Laboratory: active constraints at a predicted optimum

This laboratory prepares the reader for Extended Vignette 29 without re-teaching optimization.

```r
sp_act <- mix_spec(
  c("A", "B", "C"),
  lower = c(0.10, 0.10, 0.10),
  upper = c(0.70, 0.70, 0.70),
  A = matrix(c(1, 1, 0), nrow = 1),
  b = 0.75,
  dir = "<="
)

V <- mix_vertices(sp_act)
V
```

Choose any vertex and identify which bounds or inequalities are active. Then explain how an optimum at that vertex should be reported:

> The fitted optimum occurs at the intersection of the upper/combined formulation restrictions, so its location is conditional on the imposed feasible region.

The purpose of this exercise is to train the analyst to interpret boundaries scientifically rather than treating them as invisible numerical constraints.

---

## C4. Laboratory: categorized mixture geometry

Imagine two groups:

- organic components: O1, O2;
- mineral components: M1, M2, M3.

```r
cats <- list(
  organic = c("O1", "O2"),
  mineral = c("M1", "M2", "M3")
)

sp_cat <- mix_spec(unlist(cats, use.names = FALSE))

Dcat <- mix_categorized_design(
  sp_cat,
  categories = cats,
  category_totals = c(organic = 0.60, mineral = 0.40),
  between_degree = 2,
  within_degree = 2,
  seed = 240401
)

head(Dcat$data)
```

### Questions

- What does it mean to hold the organic category at 0.60?
- Which variation occurs within categories?
- Which variation occurs between category totals?
- Why should the grouped design structure not be confused with a specific historical categorized-component coefficient transformation?

---

# Appendix D. Geometry troubleshooting matrix

| Symptom | Likely cause | Scientific response |
|:--|:--|:--|
| `mix_vertices()` returns no feasible vertices | inconsistent bounds/constraints | audit constraints and units before design |
| many vertices differ only numerically | near-degenerate region/tolerance issue | inspect independent-coordinate spread and tolerance |
| inverse transformation slightly misses total | floating-point accumulation | compare with declared tolerance; do not round prematurely |
| pseudocomponents contain negative values | input mixture violates bounds | validate original data rather than clipping silently |
| U-pseudocomponent transformation unstable | upper bounds nearly collapse region | inspect feasibility and effective width |
| categorized design becomes enormous | too many categories/degrees | simplify degrees or redesign scientifically |
| plotted triangle looks large but feasible polygon tiny | constraints occupy narrow subregion | label feasible polygon explicitly |
| fitted model later shows severe collinearity | region lacks independent spread | simplify model or redesign; do not blame coefficients alone |

---

# Appendix E. Guided geometry exercises

### Exercise 1. Bound feasibility

Create a four-component system whose lower bounds sum to 0.95. Explain how little total mixture mass remains free and why a high-degree lattice would be inefficient.

### Exercise 2. Impossible system

Construct lower bounds that sum to 1.05. Predict what should happen before running the code, then verify package behavior. Explain why an informative error is preferable to silently rescaling the bounds.

### Exercise 3. Equality dimension

Start with four components and impose `A + B = 0.50`. Determine the effective number of freely varying dimensions after considering both the mixture total and the additional equality.

### Exercise 4. Active-set reasoning

For a three-component region with one general inequality, identify the constraints active at every extreme vertex and classify each as lower bound, upper bound, or general inequality.

### Exercise 5. Center choice

Transform the same set of mixtures using the default center and a commercial reference formulation. Explain which numerical values change and which scientific compositions do not.

### Exercise 6. Local sphere

Define a spherical local region around a current formulation. Explain why the sphere is defined in independent coordinates rather than directly using three ordinary component axes.

### Exercise 7. Ellipsoid

Create an ellipsoid that allows more variation in one independent direction than another. Propose an operational reason for this anisotropy.

### Exercise 8. Pseudocomponent interpretation

For lower bounds A = 0.20, B = 0.10, C = 0.10, calculate manually the pseudocomponents for A = 0.50, B = 0.20, C = 0.30 and compare with `mix_pseudocomponents()`.

### Exercise 9. Slack component

Explain why choosing a chemically inert carrier as slack may be more interpretable than choosing the biologically active component, even if fitted values are unchanged under a reparameterization.

### Exercise 10. Major/minor system

Design a hypothetical fertilizer blend with two major macronutrient carriers and three minor micronutrient carriers. Define plausible major totals and explain why one global lattice degree may be inefficient.

### Exercise 11. Category design

Create three categories with two components each. Discuss how category totals and within-category composition answer different scientific questions.

### Exercise 12. Reviewer exercise

A manuscript reports only “a three-component simplex design was used” although every component had bounds. Write a reviewer comment requesting the missing geometric information needed for reproducibility.

---

# Appendix F. Reviewer-style geometry audit

A reviewer or thesis examiner should be able to answer all of the following from the methods section:

1. What is the mixture total?
2. What are the original component units?
3. What are the exact lower and upper bounds?
4. Are there combined-component constraints?
5. Are any equalities imposed beyond the total?
6. Is the full simplex or only a subregion scientifically admissible?
7. Were constraints declared before responses were analyzed?
8. Can the extreme vertices be reconstructed?
9. Were pseudocomponents used, and were results back-transformed?
10. Does the effective dimension support the fitted model?
11. Are category/major-minor structures described clearly?
12. Are all reported recommended formulations inside the region?

If any answer is no, the geometry is incompletely documented.

---

# Appendix G. Interpretation language templates

### Full simplex

> The formulation consisted of three nonnegative component proportions constrained to sum to one. No additional component bounds were imposed, so the experimental region was the complete two-dimensional simplex.

### Bounded region

> Component-specific lower and upper limits restricted the admissible formulations to a convex subregion of the simplex. All design, prediction, and optimization steps were performed within this declared feasible region.

### General linear restriction

> In addition to individual bounds, the combined fraction of A and B was constrained to be no greater than 0.75. The resulting extreme vertices were enumerated before design generation to verify feasibility.

### Pseudocomponents

> Lower-bound pseudocomponents were used as an internal coordinate transformation. Final formulations and all scientific interpretations were reported on the original component scale.

### Narrow region

> The feasible region occupied a narrow subset of the simplex, limiting independent compositional variation. Consequently, model complexity and design conditioning were assessed explicitly before inferential interpretation.


---

# Appendix H. Applied geometry case bank

## H1. Fertilizer carrier with mandatory micronutrient fraction

A fertilizer granule contains two macronutrient carriers and one micronutrient premix. The premix cannot fall below a regulatory minimum, while the first carrier has an upper limit imposed by solubility. The correct first analysis is not a quadratic regression. It is a feasible-region audit. Encode the individual limits in `mix_spec()`, enumerate vertices, and verify that the candidate formulations do not collapse into a narrow edge. If a later optimum lands at the micronutrient minimum, the interpretation must state that the selected composition is conditional on the regulatory floor. A recommendation to reduce the premix below that floor would be extrapolation outside the admissible problem rather than a statistical discovery.

## H2. Pesticide blend with combined active-ingredient ceiling

Suppose A and B are active ingredients and C is an adjuvant. Toxicological guidance imposes `A + B <= 0.65`. This combined restriction can remove a large corner of the full simplex. A full triangular response plot remains a useful coordinate frame, but the admissible polygon must be shown clearly. The extreme vertices identify the most concentrated active combinations that can legally be tested. The eventual design should be generated inside this polygon. The design question belongs to Vignette 25, but the legality and geometry of the region are fixed here.

## H3. Potting substrate with lower-bound pseudocomponents

A substrate requires at least 25% structural material, 10% organic amendment, and 5% biochar. L-pseudocomponents can transform the remaining free fraction into a standard simplex. The transformed vertex corresponding to “100% pseudocomponent A” actually means “all free fraction allocated to A after all mandatory minima are already present.” This distinction should be explained in teaching materials because a pseudocomponent vertex is not a pure original material. Final tables should report the original component proportions, while pseudocomponents may be retained as internal design coordinates.

## H4. Nutrient solution around a commercial reference blend

A company wants to explore only a small neighborhood around its current nutrient formulation. A sphere or ellipsoid in independent coordinates can define a local region without breaking the sum constraint. An ellipsoid is preferable when larger movement is acceptable along one compositional contrast than another. For example, the nitrate/ammonium contrast may be allowed to vary widely while total organic-N substitution must remain close to the current product. The local region should be justified from process and agronomic knowledge, not chosen merely to create a well-conditioned model.

## H5. Categorized components in organic-mineral fertilizer

Suppose three organic ingredients and two mineral carriers are first considered within their categories, while the total organic fraction is fixed near 60%. `mix_categorized_design()` can create a grouped design geometry. The scientific report should distinguish between variation **between category totals** and variation **within each category**. If a historical double-Scheffé coefficient transformation is not part of the validated implementation, do not imply that the package reproduces it merely because the grouped design is available. The design object and the model parameterization are separate claims.

---

# Appendix I. Short-answer geometry review

1. **Why are there only `q - 1` independent coordinates?** Because the component total supplies one exact linear constraint.
2. **What is an extreme vertex?** A corner of the feasible convex region created by simultaneously active constraints.
3. **Can a feasible region still be statistically poor?** Yes. It can be extremely narrow or nearly lower-dimensional.
4. **Do pseudocomponents change the physical recipe?** No. They change coordinates and must be back-transformed.
5. **When is a slack component useful?** When one ingredient is naturally the balancing remainder.
6. **Does a full ternary triangle mean every point is allowed?** Not when bounds or general restrictions define a smaller feasible polygon.
7. **Why record units?** A proportion/percentage mismatch can invalidate all constraint checks.
8. **Can constraints be chosen after seeing response data?** They should normally be pre-specified from independent scientific or operational requirements.
9. **What should happen before optimal design?** Feasibility and vertices should be confirmed.
10. **What should be reported from a transformed system?** Both the transformation definition and original-scale final compositions.
